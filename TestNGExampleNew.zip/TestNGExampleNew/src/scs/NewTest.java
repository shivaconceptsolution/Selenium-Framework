package scs;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeGroups;

public class NewTest {
	
  	
  @Test(groups={"A"})
  public void testcase1() {
	  System.out.print("TEST CASE CODE 1");
  }
  
  @Test(groups={"A"})
  public void testCase2() {
	  System.out.print("TEST CASE CODE 2");
  }
  @Test(groups={"B"})
  public void testCase3() {
	  System.out.print("TEST CASE CODE 3");
  }
  @BeforeTest
  public void beforeTest() {
	  System.out.print("BEFORE TEST CASE CODE");
  }

  @AfterTest
  public void afterTest() {
	  System.out.print("AFTER TEST CASE CODE");
  }
  @BeforeGroups
  public void beforeGroup() {
	  System.out.print("BEFORE GROUP CODE");
  }

  @AfterGroups
  public void afterGroup() {
	  System.out.print("AFTER GROUP CODE");
  }

}
