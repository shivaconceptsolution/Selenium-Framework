package scs;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class TestNGExample {
 WebDriver scs;
  @Test
  public void verifyHomePageTitle() {
	    String s = scs.getTitle();
	    if(s.length()<=64)
	    {
	    System.out.println("Title is Valid");
	    }
	    else
	    {
	    	System.out.println("Title is Invalid");
	    }
  }
  @BeforeTest
  public void loadHomePage() {
	  System.setProperty("webdriver.chrome.driver", "c://chromedriver.exe");
	  scs= new ChromeDriver();
	  scs.get("https://eroomrent.in");
  }

  @AfterTest
  public void terminateHomePage() {
	  scs.close();
  }

}
